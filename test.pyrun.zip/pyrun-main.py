import os;

def init():
	#possible future code here
	return();

if __name__ == "__main__":
	init();
	print(os.getcwd());
